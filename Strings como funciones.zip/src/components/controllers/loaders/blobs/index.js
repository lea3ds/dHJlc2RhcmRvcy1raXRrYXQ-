import React from 'react'
import './index.css'

let Loader = () =>
        <div className="loader-container-blobs ">
            <div className = "centered">
                <div className = "blob-1"/>
                <div className = "blob-2"/>
            </div>
        </div>;

export default Loader