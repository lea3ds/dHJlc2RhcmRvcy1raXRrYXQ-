import React from 'react'
import './index.css'

let Loader = () =>
            <div className="full-screen-page">
                <div className="loader-container-ping-pong section-page">
                    <div className="board-ping-pong">
                        <div className="left-ping-pong">
                        </div>
                        <div className="right-ping-pong">
                        </div>
                        <div className="ball-ping-pong">
                        </div>
                        <div className="ballhit-ping-pong">
                        </div>
                    </div>
                </div>
            </div>;

export default Loader