import Component from "./toolbar";
export default Component;