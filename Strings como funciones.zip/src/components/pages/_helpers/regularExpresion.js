/*

const lettersReg = /^[a-zA-Z\s]*$/;
const emailValueReg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
const intValueReg = /^[0-9]+$/;
const decimalValueReg = intValueReg; // MOCK!
const stringValueReg = /^[a-zA-Z0-9\s]*$/;

//http://rubular.com
export const textNullReg = /^[a-zA-Z0-9\s]*$/;
export const textReg = /^[a-zA-Z0-9\s]+$/;
export const intReg = /^[0-9]+$/;
export const decimalReg =intReg;

*/