export const getProducts = () => (dispatch, getState) => {
    return Promise.resolve();
}
