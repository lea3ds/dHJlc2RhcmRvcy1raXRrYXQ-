
import reducer from './_reducer';
export { reducer }
export * from './_actions';

export const remoteUrl = 'Synchronizator';
